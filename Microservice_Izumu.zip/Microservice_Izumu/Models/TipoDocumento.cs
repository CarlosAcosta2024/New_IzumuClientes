﻿namespace Microservice_Izumu.Models
{
    public class TipoDocumento
    {
        public int Id { get; set; }
        public string Cod_TipoDocumento { get; set; }
        public string NombreTipoDocumento { get; set; }
    }
}
