﻿namespace Microservice_Izumu.Models
{
    public class Plan
    {
        public int Id { get; set; }
        public string Nombre_Plan { get; set; }
    }
}
